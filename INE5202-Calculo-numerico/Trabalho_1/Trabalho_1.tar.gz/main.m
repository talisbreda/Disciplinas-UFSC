# Questão 1

questao_1;

# Questão 2.1

n1 = 10; n2 = 20; n3 = 40;
A = questao_2_1a(n1, n2, n3);
x = questao_2_1bc(A, n3);

# Questão 2.2

questao_2_2a(A, n3);
questao_2_2b(A, n3);

# Questão 2.3

questao_2_3(n1, n3);

# Questão 3

n1 = 10; n2 = 40;
[t, r, d, b] = questao_3a(n1, n2)
questao_3b(t, r, d, b, n2);
