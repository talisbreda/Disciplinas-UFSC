package org.trabalho2.Q3;

import org.trabalho2.Grafo.Vertice;

import java.util.Set;

public interface SubsetSizeComparator {
    int compare(Set<Vertice> set1, Set<Vertice> set2);
}
